Commands/tools I have been using frequently

# NMAP 

Nmap UDP scan ```nmap <IP> -sU```

Output the nmap scan in 3 major formats ```nmap <IP> -oA filename```

nmap scan to do service and OS detection and scan all ports ```nmap -p- -SV -A <IP>```

[https://www.stationx.net/nmap-cheat-sheet/]

[https://highon.coffee/blog/nmap-cheat-sheet/]

# Nikto

```nikto -h <IP>```

# Directories of interest (linux)
Digital ocean has become my favorite resource for learning about Linux, straight to the point and easy to understand.

```/etc/```

```/etc/passwd```

```/etc/fstab```

```/etc/hosts```

```/etc/init.d```

```/usr/sbin```

[https://www.digitalocean.com/community/tutorials/how-to-use-passwd-and-adduser-to-manage-passwords-on-a-linux-vps]

display the first few lines of a file ```head file.txt```
display the last few lines of a file ```tail file.txt```
