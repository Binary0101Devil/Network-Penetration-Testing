# OSCP-PWK-Prep-Resources-
A list of the resources I have been using as I prepare for the exam

Update: changed wording so that it didnt seem like I already have the certification. My exam is scheduled for the end of December. I also have some more resources that I have found helpful since the last update. I will be adding those sometime this week

  # OSCP Experience
This are the blogs I have found that have given me a good direction to start as I prepared for the course

https://www.hacksplaining.com/

http://www.abatchy.com/search/label/OSCP%20Prep

http://www.techexams.net/forums/security-certifications/113355-list-recent-oscp-threads.html

http://www.jasonbernier.com/oscp-review/

https://localhost.exposed/path-to-oscp/

https://pinboard.in/u:unfo/t:oscp

# The Basics - Start Here
these are the resources I used to get more comfortable with linux, scripting, TCP/IP, etc. I recommend starting with these especially if you dont have much/any experience

https://pentesterlab.com/bootcamp

http://www.penguintutor.com/linux/basic-network-reference

https://www.cybrary.it/course/advanced-penetration-testing/

https://tulpasecurity.files.wordpress.com/2016/09/tulpa-pwk-prep-guide1.pdf

# Metasploit 
although it has been said that Metasploit use is limited during the exam, Offensive Security recommends getting more familiar with Metasploit. I have been going through the metasploit unleashed course its really good info, i would be suprised if I dont have to come back to this repeatedly

https://www.offensive-security.com/metasploit-unleashed/

https://community.rapid7.com/community/metasploit/blog/2016/11/15/test-your-might-with-the-shiny-new-metasploitable3

# Linux Exploitation

https://sploitfun.wordpress.com/2015/06/26/linux-x86-exploit-development-tutorial-series/

Privilege Escalation - Linux

https://blog.g0tmi1k.com/2011/08/basic-linux-privilege-escalation/

# TCPDump

https://danielmiessler.com/study/tcpdump/

# Buffer Overflows

https://www.sans.org/reading-room/whitepapers/threats/buffer-overflows-dummies-481

https://www.exploit-db.com/docs/28475.pdf

# Enumeration

https://hackercool.com/2016/07/smb-enumeration-with-kali-linux-enum4linuxacccheck-smbmap/

https://null-byte.wonderhowto.com/how-to/hack-like-pro-reconnaissance-with-recon-ng-part-1-getting-started-0169854/

http://0daysecurity.com/penetration-testing/enumeration.html

# Cheat Sheets for All the Things!!!!!!!

https://www.sans.org/security-resources/sec560/netcat_cheat_sheet_v1.pdf

https://highon.coffee/blog/nmap-cheat-sheet/

http://www.cheat-sheets.org/saved-copy/Notepad++_Cheat_Sheet.pdf

http://www.isical.ac.in/~pdslab/2016/lectures/bash_cheat_sheet.pdf

http://pentestmonkey.net/cheat-sheet/shells/reverse-shell-cheat-sheet

https://www.sans.org/security-resources/GoogleCheatSheet.pdf

https://www.tunnelsup.com/python-cheat-sheet/

https://www.tunnelsup.com/metasploit-cheat-sheet/

# Reverse and Bind Shell tutorials

http://resources.infosecinstitute.com/icmp-reverse-shell/#gref

# Text Editor Cheat Sheets

https://vim.rtorr.com/ - Vim

